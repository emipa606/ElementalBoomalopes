# Elemental-Boomalopes

Boomalopes that do more than go boom.

These special boomalopes all mastered one of the Elements of RimWorld: Smoke, Firefoam, Stun and EMP. Some of them go boom, some of them go zap. Others go poof!

Want to use boomalopes to your tactical advantage against mechanoids? You can. If you want, you can even use them to protect your base against fire! Let the boomies do the fighting for you--- but beware manhunter packs.

B18 update made possible by HarryDicks

v1.0 update by Alias
